[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/1Cmobile/viber-1c/tree/master)

# Viber буфер. Бот Viber на платформе 1С Предприятие

![logo](web/images/logo.jpg)

## Промежуточное хранение Вайбер сообщений. 

## Протестировать работу данного робота можно написав в личку паблик аккаунту [http://viber.com/4098](http://viber.com/4098)

## [Подробнее в этой публикации http://infostart.ru/public/588629/](http://infostart.ru/public/588629/)